function dataToggleShow() {
    var x = document.getElementById("data-show");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

function dataToggleShow2() {
    var x = document.getElementById("data-show2");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

function dataToggleShow3() {
    var x = document.getElementById("data-show3");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

function dataToggleShow4() {
    var x = document.getElementById("data-show4");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

function dataToggleShow5() {
    var x = document.getElementById("data-show5");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

function dataToggleShow6() {
    var x = document.getElementById("data-show6");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}